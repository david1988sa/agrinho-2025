let player, sementes = [], arvores = [];
let temperatura = 33;
let sementeColetada = false;

function setup() {
  createCanvas(600, 400);
  player = { x: width / 2, y: height - 60 };
  textAlign(CENTER, CENTER);
}

function draw() {
  background(200, 250, 200);

  // Informações
  fill(0);
  textSize(18);
  text("🌡️ Temperatura: " + temperatura.toFixed(1) + "°C", width / 2, 30);
  text("🌰: " + (sementeColetada ? "Sim" : "Não") + " | 🌳 Árvores: " + arvores.length, width / 2, 60);
  text("➡️⬅️ Mover | ⬆️ Plantar", width / 2, 90);

  // Temperatura
  temperatura += 0.01;

  // Áreas de plantio
  fill(100, 200, 100);
  rect(100, height - 40, 100, 20);
  rect(400, height - 40, 100, 20);
  textSize(14);
  fill(0);
  text("Área Verde", 150, height - 50);
  text("Área Verde", 450, height - 50);

  // Jogador
  textSize(40);
  text("🧒", player.x, player.y);

  if (keyIsDown(LEFT_ARROW)) player.x -= 4;
  if (keyIsDown(RIGHT_ARROW)) player.x += 4;
  player.x = constrain(player.x, 20, width - 20);

  // Sementes
  for (let i = sementes.length - 1; i >= 0; i--) {
    text("🌰", sementes[i].x, sementes[i].y);
    sementes[i].y += 2;

    if (
      !sementeColetada &&
      dist(sementes[i].x, sementes[i].y, player.x, player.y) < 25
    ) {
      sementeColetada = true;
      sementes.splice(i, 1);
    }

    if (sementes[i] && sementes[i].y > height) sementes.splice(i, 1);
  }

  if (frameCount % 100 === 0) {
    sementes.push({ x: random(50, width - 50), y: 0 });
  }

  // Árvores
  textSize(28);
  for (let arv of arvores) {
    text("🌳", arv.x, arv.y);
  }

  // Fim de jogo
  if (temperatura >= 45) {
    textSize(30);
    fill(255, 0, 0);
    text("🔥 Planeta superaquecido!", width / 2, height / 2);
    noLoop();
  }

  if (temperatura <= 15) {
    textSize(28);
    fill(0, 150, 0);
    text("✅ Planeta mais fresco! 🌍", width / 2, height / 2);
    noLoop();
  }
}

function keyPressed() {
  if (keyCode === UP_ARROW && sementeColetada) {
    if (
      (player.x >= 100 && player.x <= 200) ||
      (player.x >= 400 && player.x <= 500)
    ) {
      arvores.push({ x: player.x, y: player.y + 50 });
      temperatura -= 1.2;
      sementeColetada = false;
    }
  }
}
